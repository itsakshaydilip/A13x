# Revention - Maya Autosave Utility

**Version:** 0.0.2  
**Last Updated:** January 2026  
**Compatible with:** Autodesk Maya (All versions with PySide/PySide2 support)

> Automatic versioned Maya ASCII file backup system with configurable intervals and custom naming conventions.

---

## Overview

Revention is a production-safe Maya autosave utility that creates incremental, versioned Maya ASCII backups at configurable intervals. Features include automatic version numbering, custom file suffixes, persistent user preferences, and clean shutdown handling to prevent data loss.

---

## Features

- **Automatic Versioning** - Saves files as `BaseName_SUFFIX_V###.ma` with auto-incrementing version numbers
- **Configurable Intervals** - Set autosave frequency from 1-60 minutes (default: 15 minutes)
- **Custom Suffixes** - Choose from RIG, LDV, MDL, GRM, SIM for file organization
- **Custom Save Paths** - Specify exact folder for autosaves with environment variable support
- **Persistent Preferences** - Saves interval, suffix, and path settings between sessions
- **Clean UI** - Modern Qt interface with minimize, preview, and browse functionality
- **Safe Shutdown** - Automatically stops on Maya exit to prevent orphaned processes
- **Non-Destructive** - Preserves original scene name and working state

---

## Requirements

- **Software:** Autodesk Maya (any version with PySide/PySide2 support)
- **Python:** Maya's bundled Python environment
- **Dependencies:** PySide2/PySide (included with most Maya versions)

---

## Installation

### Quick Install

1. **Download** `revention_autosave.py` to a folder on disk (e.g., `C:\tools\revention_autosave\`)

2. **Open Maya** Script Editor (Python tab)

3. **Add to sys.path and import:**

```python
import sys
sys.path.append(r'C:\tools\revention_autosave')
import revention_autosave
revention_autosave.show_ui()
```

### Verify Installation

The UI should appear with all controls active. Check the preview field to confirm filename generation.

---

## Usage

### Launch the Tool

```python
import revention_autosave
revention_autosave.show_ui()
```

### Basic Workflow

1. **Open** your Maya scene
2. **Launch** Revention UI
3. **Configure Settings:**
   - **Base Name** (optional): Custom name or leave blank to use scene name
   - **Suffix**: Choose RIG/LDV/MDL/GRM/SIM based on file type
   - **Interval**: Set minutes between autosaves (minimum 1, default 15)
   - **Custom Path** (optional): Browse to specific save folder
4. **Click "Start Autosave"** - First save executes immediately
5. **Minimize** the UI to keep working (autosave continues in background)

### UI Controls

- **Base Name Field** - Optional custom filename (uses scene name if blank)
- **Suffix Dropdown** - File type identifier (RIG/LDV/MDL/GRM/SIM)
- **Interval Spinner** - Minutes between autosaves (1-60)
- **Custom Path Field** - Override default save location
- **Browse Button** - Select custom save directory
- **Preview Field** - Shows next filename that will be created
- **Start/Stop Autosave** - Toggle autosave timer
- **Minimize Button** - Hide UI while autosave runs

### Filename Format

Files are saved as: `<BaseName>_<SUFFIX>_V<###>.ma`

**Examples:**
- `CharacterRig_RIG_V001.ma`
- `CharacterRig_RIG_V002.ma`
- `PropModel_MDL_V015.ma`

### Save Directory Logic

1. **Custom Path** (if specified): Uses the path from Custom Path field
2. **Scene Directory**: If scene is saved, uses same folder as scene file
3. **Project Scenes Folder**: Falls back to project's `/scenes` directory
4. **Project Root**: Uses project root if scenes folder doesn't exist
5. **User Home**: Last resort fallback to user's home directory

---

## Key Components

### Core Functions

- **increment_version_filename()** - Finds highest V### and increments
- **perform_autosave()** - Executes save with version increment
- **get_preferences_path()** - Returns JSON preferences file location
- **save_preferences() / load_preferences()** - Persist user settings

### Preferences Storage

Settings are saved to: `<Maya Preferences>/revention_autosave_prefs.json`

**Stored Settings:**
- Custom Path
- Suffix (RIG/LDV/MDL/GRM/SIM)
- Interval (minutes)

### Safety Features

- **QTimer Parent**: Timer is parented to UI window, stops on window close
- **ScriptJob Cleanup**: Maya scriptJob stops autosave on application quit
- **Scene Name Preservation**: Original scene name restored after each save
- **Regex Validation**: Base name validated for filesystem safety

---

## Troubleshooting

### Import errors about maya.cmds
- Script must run inside Maya (not standalone Python)
- Ensure Maya's environment is active

### PySide/shiboken import failures
- Verify Maya version includes PySide2/PySide
- Check Maya documentation for Python binding availability

### Autosave doesn't write files
- Check folder permissions on save directory
- Verify path exists (script creates if needed)
- Check Maya's Script Editor for error messages

### Preferences not loading
- Check Maya preferences folder is writable
- Delete `revention_autosave_prefs.json` to reset

### Files not incrementing
- Ensure existing files follow `_V###.ma` pattern
- Check regex validation isn't rejecting base name

---

## Technical Details

- **Language:** Python 2.7/3.x (Maya compatible)
- **UI Framework:** PySide2/PySide (Qt-based)
- **File Format:** Maya ASCII (.ma)
- **Version Detection:** Regex pattern matching
- **Persistence:** JSON preferences file
- **Timer System:** Qt QTimer with parent-based lifecycle
- **Shutdown Hook:** Maya scriptJob for clean exit

---

**Author:** Scripts Portfolio  
**License:** Apache License 2.0
