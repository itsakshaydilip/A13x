"""
Quick script to verify shiboken2 is available in Maya
Run this in Maya's Script Editor
"""

try:
    from shiboken2 import wrapInstance
    print("✓ shiboken2 is installed")
    import shiboken2
    print(f"Location: {shiboken2.__file__}")
    print(f"Version: {shiboken2.__version__}")
except ImportError as e:
    print("✗ shiboken2 not found")
    print(f"Error: {e}")
    
try:
    from PySide2 import QtCore
    print(f"✓ PySide2 is installed (Qt version: {QtCore.qVersion()})")
except ImportError:
    print("✗ PySide2 not found")
