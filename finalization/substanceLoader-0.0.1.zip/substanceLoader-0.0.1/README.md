# Substance Loader - Arnold Texture Loader for Maya

**Version:** 1.0  
**Last Updated:** January 2026  
**Compatible with:** Autodesk Maya with Arnold Renderer

> Texture loader with automatic color space assignment and Arnold-optimized node setup for PBR workflows.

---

## Overview

Substance Loader is a Maya texture loading utility designed for Arnold renderer workflows. It detects texture types from filenames, assigns correct color spaces, and creates properly configured Arnold shader networks with minimal user input. It supports per-slot browsing, scope-based assignment (object or faces), and UDIM filename conversion to Maya’s <UDIM> pattern. When assigning to faces, the face selection is remembered after clicking 'Select', so you can change your selection before applying textures.

---

## Features

- **Automatic Texture Detection** - Identifies diffuse, roughness, metalness, and normal maps from filenames
- **Smart Color Space Assignment** - Automatically sets sRGB for color maps, Raw for data maps
- **Arnold-Optimized Nodes** - Creates aiNormalMap and aiColorCorrect nodes where appropriate
- **Per-Slot UI** - Individual slots for each texture type with browse buttons
- **Scope-Based Assignment** - Apply to first selected object or selected faces (face selection is remembered after clicking 'Select')
- **Auto Shader Setup** - Creates/uses aiStandardSurface and ensures shading group
- **Alpha is Luminance** - Automatically enabled for roughness/metalness maps
- **File Browser Integration** - Browse and load textures with native file dialogs
- **UDIM Support** - Converts 1001-style filenames to <UDIM> when found

---

## Requirements

- **Software:** Autodesk Maya with Arnold renderer installed
- **Python:** Maya's bundled Python environment
- **Renderer:** Arnold (mtoa plugin loaded)
- **Dependencies:** None (uses maya.cmds only)

---

## Installation

### Quick Install

1. **Download** `substance_loader.py` to your Maya scripts directory:
   ```
   Windows: C:\Users\<username>\Documents\maya\<version>\scripts\
   Mac:     ~/Library/Preferences/Autodesk/maya/<version>/scripts/
   Linux:   ~/maya/<version>/scripts/
   ```

2. **Ensure Arnold is loaded** in Maya (Windows > Settings/Preferences > Plug-in Manager > mtoa)

3. **Restart Maya** or refresh scripts

### Verify Installation

Open Maya Script Editor (Python tab) and run:

```python
import substance_loader
print("✓ Substance Loader installed successfully!")
```

---

## Usage

### Launch the Tool

```python
import substance_loader
substance_loader.create_drag_drop_ui()
```

### Basic Workflow

1. **Launch** the Substance Loader UI
2. **Select Target Objects or Faces**
3. **Choose Scope** (first selected object or selected faces)
4. **Load Textures** using the **Browse** buttons in each slot
5. **Apply Textures** to create/assign an aiStandardSurface shader

**Note:**
- When using the 'Selected faces' scope, click 'Select' to remember your face selection. You can then change your selection before clicking 'Apply Textures'—the textures will be applied to the originally selected faces.

### UI Controls

**Texture Slots:**
- **Diffuse/Base Color** - Color map (sRGB color space)
- **Roughness** - Roughness map (Raw, alpha is luminance)
- **Metalness** - Metallic map (Raw, alpha is luminance)
- **Normal** - Normal map (Raw, creates aiNormalMap node)

**Buttons:**
- **Select** - Refresh selection info and (for faces) remember the current face selection
- **Browse** - Open file browser for each texture type
- **Apply Textures** - Create/assign shader and connect selected textures (uses remembered faces if in face mode)
- **Clear All** - Reset texture slots

### Supported Filename Patterns

**Diffuse/Base Color:**
- Keywords: `diffuse`, `basecolor`, `albedo`, `base_color`, `_bc`, `_diff`
- Example: `wood_BaseColor.png`, `metal_diffuse.jpg`

**Roughness:**
- Keywords: `roughness`, `rough`, `_r`
- Example: `wood_Roughness.png`, `metal_rough.jpg`

**Metalness:**
- Keywords: `metalness`, `metallic`, `metal`, `_m`
- Example: `wood_Metallic.png`, `metal_m.jpg`

**Normal:**
- Keywords: `normal`, `nrm`, `_n`
- Example: `wood_Normal.png`, `metal_nrm.jpg`

---

## Key Components

### Core Functions

- **detect_texture_type()** - Identifies texture type from filename
- **get_udim_placeholder_path()** - Converts UDIM numbers to <UDIM>
- **create_file_node()** - Creates file node with correct color space
- **create_normal_setup()** - Creates aiNormalMap node for normal maps
- **create_color_balance_node()** - Creates aiColorCorrect for roughness/metalness
- **apply_textures_to_object()** - Builds/assigns shader and connects textures
- **create_drag_drop_ui()** - Builds the UI and slots

### Color Space Configuration

```python
COLORSPACE_CONFIG = {
    'diffuse': 'sRGB',      # Color data
    'basecolor': 'sRGB',    # Color data
    'albedo': 'sRGB',       # Color data
    'base_color': 'sRGB',   # Color data
    'roughness': 'Raw',     # Linear data
    'metalness': 'Raw',     # Linear data
    'metallic': 'Raw',      # Linear data
    'normal': 'Raw'         # Linear data
}
```

### Arnold Node Setup

**Diffuse/Base Color:**
- File node → Set to sRGB color space

**Roughness/Metalness:**
- File node (Raw) → aiColorCorrect node
- Alpha is Luminance enabled

**Normal:**
- File node (Raw) → aiNormalMap node

---

## Troubleshooting

### Arnold not available
- Load Arnold plugin: Windows > Settings/Preferences > Plug-in Manager > mtoa
- Verify Arnold renderer is installed for your Maya version

### Textures not detected
- Check filename contains supported keywords
- Verify files exist at specified path
- Ensure file extensions are supported (.png, .jpg, .tif, .exr)

### Color spaces incorrect
- Manually override in file node's color space attribute
- Modify COLORSPACE_CONFIG dictionary in script
- Check Maya's color management settings

### UI doesn't load textures
- Check Script Editor for error messages
- Verify file paths don’t contain special characters
- Ensure files aren’t locked or in use

### aiNormalMap node not created
- Verify filename contains "normal", "nrm", or "_n"
- Check Arnold plugin is loaded
- Ensure aiNormalMap node type exists in Maya

---

## Technical Details

- **Language:** Python 2.7/3.x (Maya compatible)
- **UI Framework:** maya.cmds (native Maya UI)
- **Renderer:** Arnold for Maya (mtoa)
- **Supported Formats:** PNG, JPG, TIF, EXR, TGA
- **Color Management:** Maya's color management system
- **Node Types:** file, aiNormalMap, aiColorCorrect

### Workflow Integration

- Compatible with Substance Painter export presets
- Works with standard PBR texture naming conventions
- Integrates with Arnold Standard Surface shaders
- Supports UDIM workflows via automatic <UDIM> conversion

---

**Author:** Akshay Dilip Kumar - itsakshaydilip 
**License:** Apache License 2.0
