# ThumbTac - Maya Pivot Grid Tool

**Version:** 0.0.2  
**Last Updated:** January 2026  
**Compatible with:** Autodesk Maya (All versions with Python support)

> Interactive 3D grid-based pivot placement tool for precise pivot point control on mesh objects.

---

## Overview

ThumbTac is a Maya modeling tool that creates a configurable 3D grid of locators spanning an object's bounding box. Click any locator to instantly set the object's pivot to that exact position. Ideal for rapid pivot placement without manual coordinate entry or transform manipulation.

---

## Features

- **Visual Grid System** - 3x3x3 (configurable) grid of locators covering object bounding box
- **One-Click Pivot Placement** - Click any locator to instantly set pivot point
- **Auto-Apply Mode** - Automatically applies pivot and cleans up grid (optional)
- **Manual Mode** - Keep grid visible for multiple operations
- **Smart Sizing** - Locators automatically scale based on object size
- **Clean UI** - Simple interface with divisions control and visibility toggle
- **Non-Destructive** - All operations preserve mesh geometry

---

## Requirements

- **Software:** Autodesk Maya (any version with Python support)
- **Python:** Maya's bundled Python environment
- **Dependencies:** None (uses maya.cmds only)

---

## Installation

### Quick Install

1. **Download** `thumbtac.py` to your Maya scripts directory:
   ```
   Windows: C:\Users\<username>\Documents\maya\<version>\scripts\
   Mac:     ~/Library/Preferences/Autodesk/maya/<version>/scripts/
   Linux:   ~/maya/<version>/scripts/
   ```

2. **Restart Maya** or refresh scripts

### Verify Installation

Open Maya Script Editor (Python tab) and run:

```python
import thumbtac
print("✓ ThumbTac loaded successfully!")
```

---

## Usage

### Launch the Tool

```python
import thumbtac
thumbtac.show_ui()
```

### Basic Workflow

1. **Select** a mesh or transform node in your Maya scene
2. **Open** the ThumbTac UI
3. **Set Divisions** (default: 3 for a 3x3x3 grid)
4. **Click "Create Grid"** - A group of locators appears covering the object's bounding box
5. **Click any locator** in the viewport - The object's pivot moves to that locator's position
6. **Grid auto-deletes** (if "Apply on Click" is enabled)

### UI Controls

- **Divisions Field** - Number of grid divisions per axis (3 = 3x3x3 grid)
- **Create Grid Button** - Generates the locator grid on selected object
- **Set Pivot Button** - Manually apply pivot from selected locator
- **Toggle Visibility Button** - Show/hide the locator grid
- **Delete Grid Button** - Remove the grid manually
- **Apply on Click Checkbox** - Auto-apply and cleanup when clicking locators

### Advanced Options

**Manual Mode:**
1. Uncheck **"Apply on Click"** before creating grid
2. Grid remains visible after clicking locators
3. Select locators and use **"Set Pivot"** button manually
4. Delete grid when finished

**Customization (Edit the script):**
- Change `DEFAULT_DIVISIONS` for different grid density
- Adjust `NODE_SCALE_FACTOR` for locator size
- Modify `CREATE_BUTTON_COLOR` for UI appearance

---

## Key Components

### Core Functions

- **create_pivot_grid()** - Generates the 3D locator grid
- **set_pivot_from_locator()** - Applies pivot from selected locator
- **toggle_grid_visibility()** - Shows/hides locators
- **delete_pivot_grid()** - Removes grid and cleanup

### Technical Features

- **Bounding Box Calculation** - Automatically sizes grid to object bounds
- **ScriptJob Integration** - Watches for selection changes to enable click-to-apply
- **Unique Naming** - Prevents name conflicts with existing scene objects
- **Auto-Scaling** - Locators size proportionally to object dimensions

### Grid Group Structure

```
pivotGrid_grp
├── locator_0_0_0
├── locator_0_0_1
├── locator_0_0_2
└── ... (27 locators for 3x3x3 grid)
```

---

## Troubleshooting

### Clicking locators does nothing
- Ensure the grid group exists and hasn't been renamed
- Verify locators have the `pivotGrid_locator` attribute
- Recreate the grid if structure was modified

### Grid doesn't appear
- Check object has valid bounding box (not empty geometry)
- Verify object is a transform or mesh node
- Check Maya's Outliner for `pivotGrid_grp`

### Locators too small/large
- Edit `NODE_SCALE_FACTOR` in the script (default: 0.02)
- Adjust `MIN_NODE_SIZE` for very small objects

### ScriptJob persists after deletion
- Close Maya to clear all script jobs
- Use `cmds.scriptJob(listJobs=True)` to view active jobs

---

## Technical Details

- **Language:** Python 2.7/3.x (Maya compatible)
- **UI Framework:** maya.cmds (native Maya UI)
- **Dependencies:** None (maya.cmds only)
- **Architecture:** Event-driven with scriptJob selection monitoring
- **Workflow:** Modeling tool (non-destructive)

---

**Author:** Akshay Dilip Kumar  - itsakshaydilip
**License:** Apache License 2.0
