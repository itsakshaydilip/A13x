# GeoMaster - Maya Geometry Sanity Checker

**Version:** 2.0  
**Last Updated:** January 18, 2026  
**Compatible with:** Autodesk Maya 2017 and later

> Comprehensive geometry, UV, shader, and scene sanity checker for Autodesk Maya with automated diagnostics and fixes.

---

## Overview

GeoMaster is a production-ready Maya tool that provides 25 automated geometry checks organized into 10 categories. It features a modern UI, one-click diagnostics, and automatic fixes for most common mesh issues. All checks work on selected objects or the entire scene, with real-time progress tracking and detailed logging.

---

## Features

- **25 Automated Checks** across 10 categories (geometry, normals, UVs, shaders, transforms, naming, performance, rigging prep, data integrity, vertex attributes)
- **One-Click Diagnostics** - Run all 25 checks sequentially with a single button
- **Automatic Fixes** - Intelligent repair system with confirmation dialogs for destructive operations
- **Visual Feedback** - Status indicators showing check results (?, OK, or issue count)
- **Viewport Highlighting** - Click status buttons to highlight problematic geometry
- **Real-time Progress** - Progress bar with percentage completion
- **Comprehensive Logging** - Timestamped output log with detailed results
- **Modern UI** - Clean, intuitive interface with color-coded status buttons

---

## Requirements

- **Software:** Autodesk Maya 2017 or later
- **Python:** Maya's bundled Python environment
- **Dependencies:** PySide2/PySide6 (included with Maya)

---

## Installation

### Quick Install

1. **Download** the project folder to your preferred location (e.g., `C:/gameGeoMaster`)
2. **Open Maya** and navigate to the Script Editor (Python tab)
3. **Run the following code:**

```python
import sys
sys.path.append(r"C:/gameGeoMaster")
import main
main.show_ui()
```

### Verify Installation

Run diagnostics to ensure everything is working:

```python
import main
main.diagnose_environment()
main.test_basic_functionality()
```

Check the log file at: `C:/gameGeoMaster/gameGeoMaster.log`

---

## Usage

### Quick Workflow

**Option 1: Run All Diagnostics (Recommended)**
1. Click **"▶ RUN ALL DIAGNOSTICS"** button at the top
2. All 25 checks run automatically (typically 5-30 seconds depending on scene size)
3. Status indicators update showing check results
4. Summary appears in the log panel showing issues found
5. Click any status button showing a number to highlight issues in the viewport
6. Click **Fix** buttons to repair issues automatically

**Option 2: Individual Checks**
- Click **Find** buttons to run specific checks one at a time
- Click **Fix** buttons to repair detected issues (with confirmation dialogs)
- Click **Status** buttons to highlight previously found issues in viewport

**UI Elements:**
- **?** = Not yet checked
- **OK** = Check passed, no issues
- **Number** = Issues found (click to highlight)

**Utility Buttons:**
- **Clear Highlighted** - Removes all mesh highlighting from viewport
- **Maya Cleanup Tool** - Opens Maya's built-in Mesh > Cleanup dialog
- **Clear Log** - Clears the output log panel
- **Audit Checks** - Developer tool to verify all checks are working correctly

---

## Key Components

### 10 Check Categories

1. **Geometry & Topology Errors** (8 checks)
   - Non-manifold edges, lamina faces, zero-area faces, coincident vertices, etc.

2. **Normal Issues** (3 checks)
   - Locked normals, reversed normals, hard edges

3. **UV & Texture Coordinate Errors** (4 checks)
   - Missing UVs, overlapping UVs, UV shell count, out-of-range UVs

4. **Shader & Material Issues** (3 checks)
   - Multiple materials, default materials, unconnected shaders

5. **Construction History & Node Issues** (2 checks)
   - Construction history, intermediate objects

6. **Transform & Pivot Problems** (2 checks)
   - Non-frozen transforms, non-centered pivots

7. **Naming & Organization Errors** (1 check)
   - Default naming patterns (pCube, pSphere, etc.)

8. **Performance & Optimization Issues** (1 check)
   - High polygon count (>100k faces)

9. **Rigging & Deformation Preparation** (1 check)
   - Non-triangulated geometry

10. **Data Integrity Issues** (3 checks)
    - Shape nodes under non-transform parents, multiple shapes per transform, orphaned nodes

### Main Files

- **main.py** - Main UI and check execution logic
- **config.py** - Configuration settings
- **logger.py** - Logging utilities
- **gameGeoMaster.log** - Runtime log file

---

## Troubleshooting

### UI doesn't appear
- Run `main.diagnose_environment()` to check setup
- Run `main.test_basic_functionality()` to verify core functions
- Check log file for errors

### Checks not working
- Ensure objects are selected (or run on entire scene)
- Check Maya's Script Editor for error messages
- Verify Maya version compatibility (2017+)

### Performance issues
- Run checks on selected objects instead of entire scene
- Close unnecessary Maya viewports
- Increase allocated memory for Maya

---

## Technical Details

- **Language:** Python 3.x
- **UI Framework:** PySide2/PySide6 (Qt-based)
- **Maya API:** maya.cmds, maya.mel, maya.OpenMaya
- **Architecture:** Modular check system with pluggable validators
- **Logging:** File-based logging with rotation support

---

**Author:** Scripts Portfolio  
**License:** Apache License 2.0
