"""
Maya Rigging Check Tool

A comprehensive tool for validating and fixing character rigging setups in Autodesk Maya.
Performs 8 critical checks including units, grid, scale, positioning, transforms, and pivots.

Features:
    - Automated rigging validation with detailed reporting
    - Auto-fix capabilities for common rigging issues
    - Interactive UI with real-time feedback
    - Supports both batch operations and individual checks
    - Hierarchy-aware processing for complex rigs

Usage:
    From Maya Script Editor:
        import rigging_check_tool
        rigging_check_tool.create_ui()  # Launch UI
        
    Command Line:
        rigging_check_tool.run_rigging_check()  # Check only
        rigging_check_tool.run_rigging_check_and_fix()  # Check and fix

Author: Rigging Team
Version: 1.0
Date: 2026-01-18
"""

from typing import Optional, List, Dict, Any, Callable
import maya.cmds as cmds  # type: ignore[import]


class RiggingCheckTool:
    """
    Main class for performing rigging validation and automated fixes.
    
    This class encapsulates all rigging check logic and provides methods for
    validating Maya scene setup, character positioning, transforms, and pivots.
    Can be used standalone or with UI integration.
    
    Attributes:
        report (List[Dict[str, str]]): List of check results with status and details
        ui_output_field (Optional[str]): Maya UI scrollField widget name for output display
    
    Check Status Values:
        - 'PASS': Check passed, no issues found
        - 'FAIL': Check failed, issues detected
        - 'WARNING': Non-critical issue or no selection
        - 'FIXED': Issue was automatically corrected
    
    Example:
        >>> tool = RiggingCheckTool()
        >>> tool.check_scale(auto_fix=True)
        >>> tool.print_report()
    """
    
    def __init__(self, ui_output_field: Optional[str] = None) -> None:
        """
        Initialize the RiggingCheckTool.
        
        Args:
            ui_output_field (Optional[str]): Maya scrollField widget name for UI output.
                If None, output goes to console only. If provided, output is duplicated
                to both console and the UI field.
        
        Returns:
            None
        """
        self.report: List[Dict[str, str]] = []  # Stores check results
        self.ui_output_field: Optional[str] = ui_output_field  # UI widget reference
        
    def ui_print(self, message: str, color: Optional[str] = None) -> None:
        """Print to both console and UI if available"""
        print(message)
        if self.ui_output_field and cmds.scrollField(self.ui_output_field, exists=True):  # type: ignore
            current_text: str = str(cmds.scrollField(self.ui_output_field, query=True, text=True) or "")  # type: ignore
            new_text: str = current_text + message + "\n"
            cmds.scrollField(self.ui_output_field, edit=True, text=new_text)  # type: ignore
            # Scroll to bottom
            cmds.scrollField(self.ui_output_field, edit=True, wordWrap=True)  # type: ignore
            cmds.refresh()  # type: ignore
        
    def add_report(self, check_name: str, status: str, details: str = "") -> None:
        """Add check result to report"""
        self.report.append({
            'check': check_name,
            'status': status,
            'details': details
        })
        
    def print_report(self) -> None:
        """Print formatted report"""
        self.ui_print("\n" + "="*70)
        self.ui_print("RIGGING CHECK TOOL - REPORT")
        self.ui_print("="*70)
        for item in self.report:
            status_symbol = "✓" if item['status'] == 'PASS' else "✗" if item['status'] == 'FAIL' else "⚠" if item['status'] == 'WARNING' else "🔧"
            self.ui_print(f"{status_symbol} {item['check']}: {item['status']}")
            if item['details']:
                self.ui_print(f"  Details: {item['details']}")
        self.ui_print("="*70 + "\n")
    
    def check_and_set_units(self, show_dialog: bool = True) -> None:
        """Check and set units to centimeters"""
        self.ui_print("\n--- Checking Units and Display ---")
        current_linear = cmds.currentUnit(query=True, linear=True)  # type: ignore
        current_angular = cmds.currentUnit(query=True, angle=True)  # type: ignore
        current_time = cmds.currentUnit(query=True, time=True)  # type: ignore
        
        self.ui_print(f"Current Linear Unit: {current_linear}")
        self.ui_print(f"Current Angular Unit: {current_angular}")
        self.ui_print(f"Current Time Unit: {current_time}")
        
        changes_made: List[str] = []
        
        # Set to standard units (centimeters)
        if current_linear != 'cm':
            cmds.currentUnit(linear='cm')  # type: ignore
            changes_made.append(f"Linear: {current_linear} → cm")
            self.add_report("Linear Units", "FIXED", f"Changed from {current_linear} to cm")
            self.ui_print("✓ Linear units set to centimeters")
        else:
            self.add_report("Linear Units", "PASS", "Already set to cm")
            self.ui_print("✓ Linear units already set to centimeters")
        
        if current_angular != 'deg':
            cmds.currentUnit(angle='deg')  # type: ignore
            changes_made.append(f"Angular: {current_angular} → deg")
            self.add_report("Angular Units", "FIXED", f"Changed from {current_angular} to degrees")
            self.ui_print("✓ Angular units set to degrees")
        else:
            self.add_report("Angular Units", "PASS", "Already set to degrees")
            self.ui_print("✓ Angular units already set to degrees")
        
        # Show confirmation dialog
        if show_dialog:
            message = "Units Configuration:\n\n"
            message += f"Linear Unit: {cmds.currentUnit(query=True, linear=True)}\n"  # type: ignore
            message += f"Angular Unit: {cmds.currentUnit(query=True, angle=True)}\n"  # type: ignore
            message += f"Time Unit: {cmds.currentUnit(query=True, time=True)}\n"  # type: ignore
            if changes_made:
                message += "\nChanges Made:\n" + "\n".join(changes_made)
            else:
                message += "\n✓ All units already correct"
            cmds.confirmDialog(title="Units Check", message=message, button=['OK'])  # type: ignore
            
    def reset_grid(self) -> None:
        """Reset grid settings based on current units"""
        self.ui_print("\n--- Resetting Grid ---")
        
        # Get current unit
        current_unit = cmds.currentUnit(query=True, linear=True)  # type: ignore
        
        # Set grid spacing based on unit
        grid_spacing = 1.0  # 1 unit spacing
        if current_unit == 'cm':
            grid_spacing = 5.0  # 5cm spacing
        elif current_unit == 'm':
            grid_spacing = 1.0  # 1m spacing
        elif current_unit == 'mm':
            grid_spacing = 10.0  # 10mm spacing
        
        # Set grid options
        cmds.grid(size=12, spacing=grid_spacing, divisions=5)  # type: ignore
        self.add_report("Grid Reset", "PASS", f"Grid spacing set to {grid_spacing} {current_unit}")
        self.ui_print(f"✓ Grid reset with spacing: {grid_spacing} {current_unit}")
        
    def reset_grid_subdivisions(self) -> None:
        """Reset grid subdivisions to 1"""
        self.ui_print("\n--- Resetting Grid Subdivisions ---")
        cmds.grid(divisions=1)  # type: ignore
        self.add_report("Grid Subdivisions", "PASS", "Set to 1")
        self.ui_print("✓ Grid subdivisions set to 1")
        
    def check_scale(self, auto_fix: bool = False) -> None:
        """Check if selected objects have scale of 1, optionally fix"""
        self.ui_print("\n--- Checking Scale ---")
        selected = cmds.ls(selection=True, transforms=True) or []  # type: ignore
        
        if not selected:
            self.add_report("Scale Check", "WARNING", "No objects selected")
            self.ui_print("⚠ No objects selected for scale check")
            return
        
        issues: List[str] = []
        fixed: List[str] = []
        for obj in selected:
            scale: Any = cmds.getAttr(f"{obj}.scale")[0]  # type: ignore
            if not all(abs(float(s) - 1.0) < 0.0001 for s in scale):  # type: ignore
                issues.append(f"{obj}: {scale}")
                if auto_fix:
                    try:
                        cmds.setAttr(f"{obj}.scaleX", 1)  # type: ignore
                        cmds.setAttr(f"{obj}.scaleY", 1)  # type: ignore
                        cmds.setAttr(f"{obj}.scaleZ", 1)  # type: ignore
                        fixed.append(obj)
                    except Exception as e:
                        self.ui_print(f"  ✗ Could not fix scale for {obj}: {e}")
        
        if issues:
            if auto_fix and fixed:
                self.add_report("Scale Check", "FIXED", f"Fixed scale on {len(fixed)} objects")
                self.ui_print(f"✓ Fixed scale to 1.0 on {len(fixed)} objects")
            else:
                self.add_report("Scale Check", "FAIL", f"{len(issues)} objects have non-uniform scale")
                self.ui_print(f"✗ Found {len(issues)} objects with scale != 1:")
                for issue in issues:
                    self.ui_print(f"  - {issue}")
        else:
            self.add_report("Scale Check", "PASS", "All selected objects have scale of 1")
            self.ui_print("✓ All selected objects have scale of 1")
    
    def check_character_position(self, auto_fix: bool = False, center_mode: str = 'ground') -> None:
        """
        Check if character is centered on grid and positioned correctly.
        
        Args:
            auto_fix: If True, automatically fix position issues
            center_mode: Centering behavior:
                - 'ground': Center X/Z, place bottom on ground (Y min at 0)
                - 'full': Center on all axes X/Y/Z (object center at origin)
                - 'x': Center only X axis
                - 'y': Center only Y axis
                - 'z': Center only Z axis
                - 'xy': Center X and Y axes
                - 'xz': Center X and Z axes
                - 'yz': Center Y and Z axes
        """
        self.ui_print(f"\n--- Checking Character Position (mode: {center_mode}) ---")
        selected = cmds.ls(selection=True, transforms=True) or []  # type: ignore
        
        if not selected:
            self.add_report("Character Position", "WARNING", "No objects selected")
            self.ui_print("⚠ No objects selected for position check")
            return
        
        # Get top-level objects (those without parents in selection or groups)
        top_level_objects: List[str] = []
        for obj in selected:
            parent = cmds.listRelatives(obj, parent=True, fullPath=True)  # type: ignore
            if not parent or parent[0] not in selected:
                top_level_objects.append(obj)
        
        # If we have top-level objects, use those; otherwise use all selected
        objects_to_process: List[Any] = top_level_objects if top_level_objects else selected
        
        self.ui_print(f"Processing {len(objects_to_process)} top-level object(s)...")
        
        for obj in objects_to_process:
            pos: Any = cmds.xform(obj, query=True, worldSpace=True, translation=True)  # type: ignore
            
            # Check centering based on mode
            centered = False
            status_details: List[str] = []
            
            if center_mode == 'ground':
                # Original behavior: centered on X and Z, bottom on ground
                centered = abs(pos[0]) < 0.001 and abs(pos[2]) < 0.001
                on_ground = pos[1] >= -0.001
                if centered and on_ground:
                    centered = True
                else:
                    if not (abs(pos[0]) < 0.001 and abs(pos[2]) < 0.001):
                        status_details.append(f"Not centered X/Z (X:{pos[0]:.3f}, Z:{pos[2]:.3f})")
                    if not on_ground:
                        status_details.append(f"Below ground (Y:{pos[1]:.3f})")
            else:
                # Check based on selected axes
                check_axes = {
                    'x': center_mode in ['x', 'xy', 'xz', 'full'],
                    'y': center_mode in ['y', 'xy', 'yz', 'full'],
                    'z': center_mode in ['z', 'xz', 'yz', 'full']
                }
                
                centered = True
                if check_axes['x'] and abs(pos[0]) > 0.001:
                    centered = False
                    status_details.append(f"X not centered: {pos[0]:.3f}")
                if check_axes['y'] and abs(pos[1]) > 0.001:
                    centered = False
                    status_details.append(f"Y not centered: {pos[1]:.3f}")
                if check_axes['z'] and abs(pos[2]) > 0.001:
                    centered = False
                    status_details.append(f"Z not centered: {pos[2]:.3f}")
            
            if centered:
                self.add_report(f"Position: {obj}", "PASS", f"Centered ({center_mode} mode)")
                self.ui_print(f"✓ {obj} is centered ({center_mode} mode)")
            else:
                if auto_fix:
                    # Center character using bounding box interpolation
                    try:
                        # Get bounding box to find center and bounds
                        bbox = cmds.exactWorldBoundingBox(obj)  # type: ignore
                        # bbox = [xmin, ymin, zmin, xmax, ymax, zmax]
                        
                        # Calculate center of bounding box (interpolation between min and max)  # type: ignore
                        center_x: float = (bbox[0] + bbox[3]) / 2.0  # type: ignore
                        center_y: float = (bbox[1] + bbox[4]) / 2.0  # type: ignore
                        center_z: float = (bbox[2] + bbox[5]) / 2.0  # type: ignore
                        
                        # Get current position
                        current_pos = cmds.xform(obj, query=True, worldSpace=True, translation=True)  # type: ignore
                        
                        # Calculate offsets based on mode
                        if center_mode == 'ground':
                            # Original behavior: center X/Z, bottom on ground
                            offset_x: float = -center_x  # type: ignore
                            offset_y: float = -bbox[1]  # type: ignore  # Move bottom to ground plane
                            offset_z: float = -center_z  # type: ignore
                        elif center_mode == 'full':
                            # Center on all axes
                            offset_x: float = -center_x  # type: ignore
                            offset_y: float = -center_y  # type: ignore
                            offset_z: float = -center_z  # type: ignore
                        elif center_mode == 'x':
                            offset_x: float = -center_x  # type: ignore
                            offset_y: float = 0.0
                            offset_z: float = 0.0
                        elif center_mode == 'y':
                            offset_x: float = 0.0
                            offset_y: float = -center_y  # type: ignore
                            offset_z: float = 0.0
                        elif center_mode == 'z':
                            offset_x: float = 0.0
                            offset_y: float = 0.0
                            offset_z: float = -center_z  # type: ignore
                        elif center_mode == 'xy':
                            offset_x: float = -center_x  # type: ignore
                            offset_y: float = -center_y  # type: ignore
                            offset_z: float = 0.0
                        elif center_mode == 'xz':
                            offset_x: float = -center_x  # type: ignore
                            offset_y: float = 0.0
                            offset_z: float = -center_z  # type: ignore
                        elif center_mode == 'yz':
                            offset_x: float = 0.0
                            offset_y: float = -center_y  # type: ignore
                            offset_z: float = -center_z  # type: ignore
                        else:
                            raise ValueError(f"Invalid center_mode: {center_mode}")
                        
                        # Calculate new position
                        new_x: float = current_pos[0] + offset_x  # type: ignore
                        new_y: float = current_pos[1] + offset_y  # type: ignore
                        new_z: float = current_pos[2] + offset_z  # type: ignore
                        
                        # Move the object
                        cmds.xform(obj, worldSpace=True, translation=[new_x, new_y, new_z])  # type: ignore
                        
                        # Verify the new position
                        verify_bbox = cmds.exactWorldBoundingBox(obj)  # type: ignore
                        verify_center_x: float = (verify_bbox[0] + verify_bbox[3]) / 2.0  # type: ignore
                        verify_center_y: float = (verify_bbox[1] + verify_bbox[4]) / 2.0  # type: ignore
                        verify_center_z: float = (verify_bbox[2] + verify_bbox[5]) / 2.0  # type: ignore
                        
                        self.add_report(f"Position: {obj}", "FIXED", 
                                      f"Centered (mode: {center_mode}) - X={verify_center_x:.3f}, Y={verify_center_y:.3f}, Z={verify_center_z:.3f}")
                        self.ui_print(f"✓ {obj} centered (mode: {center_mode}) - X={verify_center_x:.3f}, Y={verify_center_y:.3f}, Z={verify_center_z:.3f}")
                    except Exception as e:
                        import traceback
                        self.add_report(f"Position: {obj}", "FAIL", f"Could not fix: {e}")
                        self.ui_print(f"✗ Could not fix position for {obj}: {e}")
                        self.ui_print(f"  Error details: {traceback.format_exc()}")
                else:
                    self.add_report(f"Position: {obj}", "WARNING", ", ".join(status_details))
                    self.ui_print(f"⚠ {obj}: {', '.join(status_details)}")
    
    def freeze_transforms(self, only_if_needed: bool = True) -> None:
        """Freeze transforms on selected objects only if changes detected"""
        self.ui_print("\n--- Freezing Transforms ---")
        selected = cmds.ls(selection=True, transforms=True) or []  # type: ignore
        
        if not selected:
            self.add_report("Freeze Transforms", "WARNING", "No objects selected")
            self.ui_print("⚠ No objects selected to freeze transforms")
            return
        
        objects_to_freeze: List[str] = []
        
        if only_if_needed:
            # Check which objects actually need freezing
            for obj in selected:
                trans: Any = cmds.getAttr(f"{obj}.translate")[0]  # type: ignore
                rot: Any = cmds.getAttr(f"{obj}.rotate")[0]  # type: ignore
                scale: Any = cmds.getAttr(f"{obj}.scale")[0]  # type: ignore
                
                # Check if transforms are not at default values
                needs_freeze = (  # type: ignore
                    not all(abs(float(t)) < 0.0001 for t in trans) or  # type: ignore
                    not all(abs(float(r)) < 0.0001 for r in rot) or  # type: ignore
                    not all(abs(float(s) - 1.0) < 0.0001 for s in scale)  # type: ignore
                )
                
                if needs_freeze:
                    objects_to_freeze.append(obj)
        else:
            objects_to_freeze = selected
        
        if not objects_to_freeze:
            self.add_report("Freeze Transforms", "PASS", "All transforms already frozen")
            self.ui_print("✓ All transforms already at default values, no freeze needed")
            return
        
        try:
            cmds.makeIdentity(objects_to_freeze, apply=True, translate=True, rotate=True, scale=True, normal=False)  # type: ignore
            self.add_report("Freeze Transforms", "PASS", f"Froze transforms on {len(objects_to_freeze)} objects")
            self.ui_print(f"✓ Froze transforms on {len(objects_to_freeze)} objects")
            if len(objects_to_freeze) < len(selected):
                self.ui_print(f"  ({len(selected) - len(objects_to_freeze)} objects already frozen)")
        except Exception as e:
            self.add_report("Freeze Transforms", "FAIL", str(e))
            self.ui_print(f"✗ Failed to freeze transforms: {e}")
    
    def center_pivot(self, include_hierarchy: bool = True) -> None:
        """Center pivot point on selected objects and hierarchy"""
        self.ui_print("\n--- Centering Pivot Points ---")
        selected = cmds.ls(selection=True, transforms=True) or []  # type: ignore
        
        if not selected:
            self.add_report("Center Pivot", "WARNING", "No objects selected")
            self.ui_print("⚠ No objects selected to center pivot")
            return
        
        objects_to_process: List[str] = []
        
        if include_hierarchy:
            # Get all objects in hierarchy
            for obj in selected:
                objects_to_process.append(obj)
                # Get all children
                children: List[Any] = cmds.listRelatives(obj, allDescendents=True, type='transform', fullPath=True) or []  # type: ignore
                objects_to_process.extend(children)
            # Remove duplicates
            objects_to_process = list(set(objects_to_process))
        else:
            objects_to_process = selected
        
        for obj in objects_to_process:
            cmds.xform(obj, centerPivots=True)  # type: ignore
        
        self.add_report("Center Pivot", "PASS", f"Centered pivots on {len(objects_to_process)} objects (including hierarchy)")
        self.ui_print(f"✓ Centered pivots on {len(objects_to_process)} objects (including hierarchy)")
    
    def check_pivot_at_origin(self, auto_fix: bool = False, fix_top_level_only: bool = True) -> None:
        """Check if pivot point is at origin, optionally fix top-level groups"""
        self.ui_print("\n--- Checking Pivot at Origin ---")
        selected = cmds.ls(selection=True, transforms=True) or []  # type: ignore
        
        if not selected:
            self.add_report("Pivot at Origin", "WARNING", "No objects selected")
            self.ui_print("⚠ No objects selected for pivot check")
            return
        
        # Get top-level objects (those without parents in selection)
        top_level_objects: List[str] = []
        for obj in selected:
            parent = cmds.listRelatives(obj, parent=True, fullPath=True)  # type: ignore
            if not parent or parent[0] not in selected:
                top_level_objects.append(obj)
        
        objects_to_check = top_level_objects if fix_top_level_only else selected
        fixed_count = 0
        
        for obj in objects_to_check:
            pivot: Any = cmds.xform(obj, query=True, worldSpace=True, rotatePivot=True)  # type: ignore
            at_origin = all(abs(float(p)) < 0.001 for p in pivot)  # type: ignore
            
            if at_origin:
                self.add_report(f"Pivot Origin: {obj}", "PASS", "Pivot at origin")
                self.ui_print(f"✓ {obj} pivot is at origin")
            else:
                if auto_fix:
                    try:
                        cmds.xform(obj, worldSpace=True, pivots=[0, 0, 0])  # type: ignore
                        self.add_report(f"Pivot Origin: {obj}", "FIXED", f"Moved pivot from ({pivot[0]:.3f}, {pivot[1]:.3f}, {pivot[2]:.3f}) to origin")
                        self.ui_print(f"✓ {obj} pivot moved to origin (was at {pivot[0]:.3f}, {pivot[1]:.3f}, {pivot[2]:.3f})")
                        fixed_count += 1
                    except Exception as e:
                        self.add_report(f"Pivot Origin: {obj}", "FAIL", f"Could not move pivot: {e}")
                        self.ui_print(f"✗ Could not move pivot for {obj}: {e}")
                else:
                    self.add_report(f"Pivot Origin: {obj}", "WARNING", f"Pivot at ({pivot[0]:.3f}, {pivot[1]:.3f}, {pivot[2]:.3f})")
                    self.ui_print(f"⚠ {obj} pivot is at ({pivot[0]:.3f}, {pivot[1]:.3f}, {pivot[2]:.3f})")
        
        if auto_fix and fix_top_level_only and top_level_objects:
            self.ui_print(f"  (Processed {len(top_level_objects)} top-level objects in hierarchy)")
    
    def run_all_fixes(self) -> None:
        """Run all checks and apply fixes"""
        self.ui_print("\n" + "="*70)
        self.ui_print("STARTING RIGGING CHECK TOOL (WITH AUTO-FIX)")
        self.ui_print("="*70)
        
        # 1. Check and set units (with dialog)
        self.check_and_set_units(show_dialog=True)
        
        # 2. Reset grid
        self.reset_grid()
        
        # 3. Reset grid subdivisions
        self.reset_grid_subdivisions()
        
        # 4. Check and fix scale
        self.check_scale(auto_fix=True)
        
        # 5. Check and fix character position (default ground mode)
        self.check_character_position(auto_fix=True, center_mode='ground')
        
        # 6. Freeze transforms (only if needed)
        self.freeze_transforms(only_if_needed=True)
        
        # 7. Center pivot (including hierarchy)
        self.center_pivot(include_hierarchy=True)
        
        # 8. Check and fix pivot to origin (top-level groups)
        self.check_pivot_at_origin(auto_fix=True, fix_top_level_only=True)
        
        # Print final report
        self.print_report()
        
        self.ui_print("\n✓ Rigging check and fix complete!")


def run_rigging_check_and_fix():
    """Main function to run rigging checks with auto-fix (standalone, no UI)"""
    tool = RiggingCheckTool()
    tool.run_all_fixes()


# UI Global Variables
_output_field: Optional[str] = None

def get_output_field() -> Optional[str]:
    """Get the current output field reference"""
    global _output_field
    return _output_field

def set_output_field(field: Optional[str]) -> None:
    """Set the output field reference"""
    global _output_field
    _output_field = field

def clear_output() -> None:
    """Clear the output display"""
    try:
        field = get_output_field()
        if field and cmds.scrollField(field, exists=True):  # type: ignore
            cmds.scrollField(field, edit=True, text="")  # type: ignore
    except Exception as e:
        print(f"Warning: Could not clear output field: {e}")

def run_check_with_ui(check_func: Callable[..., None], *args: Any, **kwargs: Any) -> None:
    """Run a check function with UI output"""
    try:
        field = get_output_field()
        if not field or not cmds.scrollField(field, exists=True):
            cmds.warning("Output field not available. UI may have been closed.")
            return
        
        tool = RiggingCheckTool(ui_output_field=field)
        check_func(tool, *args, **kwargs)
    except Exception as e:
        import traceback
        error_msg = f"Error running check: {e}\n{traceback.format_exc()}"
        print(error_msg)
        if get_output_field() and cmds.scrollField(get_output_field(), exists=True):  # type: ignore
            tool = RiggingCheckTool(ui_output_field=get_output_field())
            tool.ui_print(f"\n✗ ERROR: {e}")
            tool.ui_print(f"See console for full traceback")

def run_all_fixes_ui() -> None:
    """Run all fixes with UI output"""
    try:
        field = get_output_field()
        if not field or not cmds.scrollField(field, exists=True):
            cmds.warning("Output field not available. UI may have been closed.")
            return
        
        clear_output()
        tool = RiggingCheckTool(ui_output_field=field)
        tool.run_all_fixes()
    except Exception as e:
        import traceback
        error_msg = f"Error running fixes: {e}\n{traceback.format_exc()}"
        print(error_msg)
        if get_output_field() and cmds.scrollField(get_output_field(), exists=True):  # type: ignore
            tool = RiggingCheckTool(ui_output_field=get_output_field())
            tool.ui_print(f"\n✗ ERROR: {e}")
            tool.ui_print(f"See console for full traceback")

def cleanup_ui() -> None:
    """Cleanup function called when window is closed"""
    set_output_field(None)  # type: ignore

def create_ui():
    """Create an enhanced UI for the rigging check tool with output display"""
    try:
        window_name = "riggingCheckToolUI"
        
        # Delete existing window if it exists
        if cmds.window(window_name, exists=True):  # type: ignore
            cmds.deleteUI(window_name)  # type: ignore
        
        # Create new window with larger size for output display
        window = cmds.window(window_name, title="Maya Rigging Check Tool v1.0", widthHeight=(650, 700),  # type: ignore
                            closeCommand=cleanup_ui)
        
        main_layout = cmds.paneLayout(configuration='vertical2', paneSize=(1, 40, 100))  # type: ignore
        
        # Left panel - Controls
        left_layout = cmds.scrollLayout(childResizable=True)  # type: ignore
        cmds.columnLayout(adjustableColumn=True, rowSpacing=10, columnAttach=('both', 10))  # type: ignore
        
        cmds.text(label="Maya Rigging Check Tool", font="boldLabelFont", height=30, backgroundColor=(0.2, 0.2, 0.2))  # type: ignore
        cmds.separator(height=10)  # type: ignore
        
        cmds.text(label="Select your character rig or objects to check", align="left", font="smallBoldLabelFont")  # type: ignore
        cmds.separator(height=5)  # type: ignore
        
        # Individual check buttons
        cmds.frameLayout(label="Individual Checks & Fixes", collapsable=True, collapse=False, backgroundColor=(0.25, 0.25, 0.25))  # type: ignore
        cmds.columnLayout(adjustableColumn=True, rowSpacing=3, columnAttach=('both', 5))  # type: ignore
        
        # 1. Units
        cmds.button(label="1. Check & Set Units",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_and_set_units, show_dialog=True),
                    annotation="Check and set scene units to cm/degrees",
                    backgroundColor=(0.4, 0.6, 0.4))
        
        # 2. Grid
        cmds.button(label="2. Reset Grid",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.reset_grid),
                    annotation="Reset grid spacing based on current units",
                    backgroundColor=(0.4, 0.6, 0.4))
        
        # 3. Grid Subdivisions
        cmds.button(label="3. Reset Grid Subdivisions",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.reset_grid_subdivisions),
                    annotation="Set grid subdivisions to 1",
                    backgroundColor=(0.4, 0.6, 0.4))
        
        cmds.separator(height=8, style='in')  # type: ignore
        
        # 4. Scale - Check and Fix buttons
        cmds.rowLayout(numberOfColumns=2, columnWidth2=(130, 130), columnAttach=[(1, 'both', 2), (2, 'both', 2)])  # type: ignore
        cmds.button(label="4. Check Scale",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_scale, auto_fix=False),
                    annotation="Check scale values (report only)",
                    backgroundColor=(0.5, 0.5, 0.5))
        cmds.button(label="Fix Scale",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_scale, auto_fix=True),
                    annotation="Fix scale to 1.0",
                    backgroundColor=(0.4, 0.6, 0.4))
        cmds.setParent('..')  # type: ignore
        
        # 5. Character Position - Check and Fix buttons
        cmds.separator(height=2)  # type: ignore
        cmds.text(label="Position Centering:", align="left", font="smallBoldLabelFont")  # type: ignore
        
        cmds.rowLayout(numberOfColumns=2, columnWidth2=(130, 130), columnAttach=[(1, 'both', 2), (2, 'both', 2)])  # type: ignore
        cmds.button(label="5. Check Position",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=False, center_mode='ground'),
                    annotation="Check character position (report only)",
                    backgroundColor=(0.5, 0.5, 0.5))
        cmds.button(label="Fix (Ground Mode)",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='ground'),
                    annotation="Center X/Z axes, place bottom on ground",
                    backgroundColor=(0.4, 0.6, 0.4))
        cmds.setParent('..')  # type: ignore
        
        # Additional centering mode buttons
        cmds.rowLayout(numberOfColumns=3, columnWidth3=(87, 87, 87), columnAttach=[(1, 'both', 2), (2, 'both', 2), (3, 'both', 2)])  # type: ignore
        cmds.button(label="Fix Full (XYZ)",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='full'),
                    annotation="Center on all axes X/Y/Z (center at origin)",
                    backgroundColor=(0.4, 0.5, 0.6))
        cmds.button(label="Fix X Only",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='x'),
                    annotation="Center only on X axis",
                    backgroundColor=(0.6, 0.4, 0.4))
        cmds.button(label="Fix Y Only",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='y'),
                    annotation="Center only on Y axis",
                    backgroundColor=(0.4, 0.6, 0.4))
        cmds.setParent('..')  # type: ignore
        
        cmds.rowLayout(numberOfColumns=3, columnWidth3=(87, 87, 87), columnAttach=[(1, 'both', 2), (2, 'both', 2), (3, 'both', 2)])  # type: ignore
        cmds.button(label="Fix Z Only",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='z'),
                    annotation="Center only on Z axis",
                    backgroundColor=(0.4, 0.4, 0.6))
        cmds.button(label="Fix XY",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='xy'),
                    annotation="Center on X and Y axes",
                    backgroundColor=(0.5, 0.5, 0.4))
        cmds.button(label="Fix XZ",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='xz'),
                    annotation="Center on X and Z axes",
                    backgroundColor=(0.5, 0.4, 0.5))
        cmds.setParent('..')  # type: ignore
        
        cmds.rowLayout(numberOfColumns=1, columnWidth1=261, columnAttach=[(1, 'both', 2)])  # type: ignore
        cmds.button(label="Fix YZ",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_character_position, auto_fix=True, center_mode='yz'),
                    annotation="Center on Y and Z axes",
                    backgroundColor=(0.4, 0.5, 0.5))
        cmds.setParent('..')  # type: ignore
        
        cmds.separator(height=8, style='in')  # type: ignore
        
        # 6. Freeze Transforms
        cmds.button(label="6. Freeze Transforms",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.freeze_transforms, only_if_needed=True),
                    annotation="Freeze transforms only if needed",
                    backgroundColor=(0.4, 0.6, 0.4))
        
        # 7. Center Pivot
        cmds.button(label="7. Center Pivot - Hierarchy",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.center_pivot, include_hierarchy=True),
                    annotation="Center pivots on all objects in hierarchy",
                    backgroundColor=(0.4, 0.6, 0.4))
        
        # 8. Pivot at Origin - Check and Fix buttons
        cmds.rowLayout(numberOfColumns=2, columnWidth2=(130, 130), columnAttach=[(1, 'both', 2), (2, 'both', 2)])  # type: ignore
        cmds.button(label="8. Check Pivot Origin",  # type: ignore 
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_pivot_at_origin, auto_fix=False, fix_top_level_only=True),
                    annotation="Check if pivot is at origin (report only)",
                    backgroundColor=(0.5, 0.5, 0.5))
        cmds.button(label="Fix Pivot",  # type: ignore
                    command=lambda x: run_check_with_ui(RiggingCheckTool.check_pivot_at_origin, auto_fix=True, fix_top_level_only=True),
                    annotation="Move pivot to origin",
                    backgroundColor=(0.4, 0.6, 0.4))
        cmds.setParent('..')  # type: ignore
        
        cmds.setParent('..')  # type: ignore
        cmds.setParent('..')  # type: ignore
        
        cmds.separator(height=10)  # type: ignore
        
        # Run all buttons
        cmds.frameLayout(label="Batch Operations", collapsable=True, collapse=False, backgroundColor=(0.25, 0.25, 0.25))  # type: ignore
        cmds.columnLayout(adjustableColumn=True, rowSpacing=5, columnAttach=('both', 5))  # type: ignore
        
        cmds.button(label="Run All Fixes",  # type: ignore 
                    command=lambda x: run_all_fixes_ui(),
                    backgroundColor=(0.3, 0.7, 0.3),
                    height=35,
                    annotation="Run all checks and automatically apply all fixes")
        
        cmds.setParent('..')  # type: ignore
        cmds.setParent('..')  # type: ignore
        
        cmds.separator(height=10)  # type: ignore
        
        # Clear output button
        cmds.button(label="Clear Output",  # type: ignore
                    command=lambda x: clear_output(),
                    backgroundColor=(0.5, 0.3, 0.3),
                    height=25)
        
        cmds.setParent('..')  # type: ignore  # Exit main columnLayout
        cmds.setParent('..')  # type: ignore  # Exit scrollLayout back to paneLayout
        
        # Right panel - Output Display
        right_layout = cmds.columnLayout(adjustableColumn=True)  # type: ignore
        
        cmds.text(label="Output Log", font="boldLabelFont", height=25, backgroundColor=(0.2, 0.3, 0.4), align="center")  # type: ignore
        
        # Scrollable output field
        field = cmds.scrollField(  # type: ignore
            editable=False,
            wordWrap=True,
            text="Ready. Select objects and run checks...\n",
            font="fixedWidthFont",
            backgroundColor=(0.15, 0.15, 0.15),
            height=600
        )
        
        # Store reference to output field
        set_output_field(field)
        
        cmds.setParent('..')  # type: ignore
        
        cmds.showWindow(window)  # type: ignore
        
        # Initial message
        cmds.scrollField(field, edit=True,  # type: ignore 
                    text="=" * 50 + "\nMaya Rigging Check Tool\n" + "=" * 50 + "\n\n" +
                         "Instructions:\n" +
                         "1. Select your character rig or objects\n" +
                         "2. Click individual checks or batch operations\n" +
                         "3. Watch this panel for real-time feedback\n\n" +
                         "Legend:\n" +
                         "✓ PASS - Check passed\n" +
                         "🔧 FIXED - Auto-fixed\n" +
                         "✗ FAIL - Failed\n" +
                         "⚠ WARNING - Needs attention\n\n" +
                         "Ready to start...\n" + "=" * 50 + "\n\n")
        
        return window
        
    except Exception as e:
        import traceback
        error_msg = f"Error creating UI: {e}\n{traceback.format_exc()}"
        print(error_msg)
        cmds.confirmDialog(title="UI Creation Error",  # type: ignore
                          message=f"Failed to create UI:\n\n{str(e)}", 
                          button=['OK'], 
                          defaultButton='OK',
                          icon='critical')
        return None


# Execute this to launch the UI
if __name__ == "__main__":
    create_ui()
